


<?php $__env->startSection('title','Clientes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    
    <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
        <h3 class="text-primary">
            <i class="bi bi-people-fill me-2"></i> Lista de Clientes
        </h3>
        <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'clientes.create')): ?>
        <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success shadow-sm">
            <i class="bi bi-person-plus-fill me-1"></i> Nuevo Cliente
        </a>
        <?php endif; ?>
    </div>

    
    <?php $__currentLoopData = ['success','error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($t)): ?>
            <div class="alert alert-<?php echo e($t=='success' ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                <i class="bi <?php echo e($t=='success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'); ?>"></i>
                <?php echo e(session($t)); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="table-responsive shadow-sm">
        <table class="table table-hover table-bordered align-middle bg-white">
            <thead class="table-primary text-center">
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>CI</th>
                    <th>Teléfono</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($cliente->idcliente); ?></td>
                    <td class="fw-semibold"><?php echo e($cliente->nombre); ?></td>
                    <td><?php echo e($cliente->ci); ?></td>
                    <td><?php echo e($cliente->telefono ?? 'No registrado'); ?></td>
                    <td>
                        <div class="btn-group">
                            <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'clientes.edit')): ?>
                            <a href="<?php echo e(route('clientes.edit',$cliente)); ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <?php endif; ?>

                            <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'clientes.delete')): ?>
                            <form action="<?php echo e(route('clientes.destroy',$cliente)); ?>" method="POST" onsubmit="return confirm('¿Eliminar cliente?');">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" title="Eliminar">
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="text-muted">No hay clientes registrados.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($clientes->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/clientes/index.blade.php ENDPATH**/ ?>