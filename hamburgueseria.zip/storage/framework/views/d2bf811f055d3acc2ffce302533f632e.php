<?php $__env->startSection('title','Usuarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="d-flex justify-content-between flex-wrap align-items-center mb-3">
        <h3 class="text-primary">
            <i class="bi bi-people-fill me-2"></i> Lista de Usuarios
        </h3>
        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success shadow-sm">
            <i class="bi bi-person-plus-fill me-1"></i> Nuevo Usuario
        </a>
    </div>

    
    <?php $__currentLoopData = ['success','error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($t)): ?>
            <div class="alert alert-<?php echo e($t=='success' ? 'success' : 'danger'); ?> alert-dismissible fade show"
                 role="alert">
                <i class="bi <?php echo e($t=='success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'); ?>"></i>
                <?php echo e(session($t)); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <form action="<?php echo e(route('usuarios.index')); ?>" method="GET"
          class="input-group mb-3 shadow-sm" onsubmit="return validarInput()">
        <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
        <input id="buscar" name="buscar" class="form-control"
               value="<?php echo e(request('buscar')); ?>"
               maxlength="25"
               pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ0-9@._\- ]{0,25}"
               placeholder="Buscar por nombre o email…">
        <button class="btn btn-outline-primary">Buscar</button>
    </form>

    
    <div class="table-responsive shadow-sm">
        <table class="table table-hover table-bordered align-middle bg-white">
            <thead class="table-primary text-center">
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Perfil</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($usuario->idusuario); ?></td>
                    <td class="fw-semibold"><?php echo e($usuario->nombre); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->telefono ?? 'No registrado'); ?></td>
                    <td>
                        <?php if($usuario->perfil_link): ?>
                            <a href="<?php echo e($usuario->perfil_link); ?>" target="_blank">
                                <img src="<?php echo e($usuario->perfil_link); ?>"
                                     class="rounded-circle" width="40" height="40" alt="Perfil">
                            </a>
                        <?php else: ?>
                            <span class="text-muted">No asignado</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($usuario->rol->nombre); ?></td>

                    
                    <td>
                        <div class="btn-group">
                            <a href="<?php echo e(route('usuarios.show',$usuario)); ?>"
                               class="btn btn-sm btn-outline-info" title="Ver">
                               <i class="bi bi-eye-fill"></i></a>

                            <a href="<?php echo e(route('usuarios.edit',$usuario)); ?>"
                               class="btn btn-sm btn-outline-warning" title="Editar">
                               <i class="bi bi-pencil-fill"></i></a>

                            <?php $esPropio = $usuario->idusuario == Auth::id(); ?>
                            <form action="<?php echo e(route('usuarios.destroy',$usuario)); ?>" method="POST"
                                  onsubmit="return <?php echo e($esPropio ? 'false' : 'confirm(\'¿Desactivar usuario?\')'); ?>;">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger"
                                        title="<?php echo e($esPropio ? 'No puedes eliminar tu propia cuenta' : 'Inactivar'); ?>"
                                        <?php echo e($esPropio ? 'disabled' : ''); ?>>
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-muted">No se encontraron usuarios.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="d-flex justify-content-center mt-3">
        <?php echo e($usuarios->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    /* Desvanecer la alerta después de 3 s (opcional) *//*
    setTimeout(()=>document.querySelectorAll('.alert').forEach(a=>{
        a.classList.remove('show');a.classList.add('fade');}),3000);*/

    /* Validar buscador */
    function validarInput(){
        const v=document.getElementById('buscar').value;
        if(!/^[A-Za-zÁÉÍÓÚáéíóúÑñ0-9@._\- ]{0,25}$/.test(v)){
            alert('Sólo letras, números, puntos y @ (máx 25).');return false;
        }
        return true;
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/usuarios/index.blade.php ENDPATH**/ ?>