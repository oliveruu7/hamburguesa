 
<?php $__env->startSection('title','Insumos registrados'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h2 class="fw-bold text-dark">
                <i class="bi bi-archive me-2 text-primary"></i> Insumos registrados
            </h2>
        </div>
        <div class="col-md-6 text-end">
            <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'insumos.create')): ?>
                <a href="<?php echo e(route('insumos.create')); ?>" class="btn btn-success shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Crear nuevo insumo
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <form method="GET" class="mb-3">
        <div class="input-group shadow-sm">
            <input name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Buscar insumo…">
            <button type="submit" class="btn btn-outline-primary">
                <i class="bi bi-search"></i>
            </button>
            <?php if(request('q')): ?>
                <a href="<?php echo e(route('insumos.index')); ?>" class="btn btn-outline-danger">Limpiar</a>
            <?php endif; ?>
        </div>
    </form>

    
    <?php $__currentLoopData = ['success', 'error', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($msg)): ?>
            <div class="alert alert-<?php echo e($msg); ?> alert-dismissible fade show" role="alert">
                <?php echo e(session($msg)); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="card shadow border-0">
        <div class="table-responsive">
            <table class="table table-striped table-hover align-middle text-center mb-0">
                <thead class="table-primary">
                    <tr>
                        <th>#</th>
                        <th class="text-start">Nombre</th>
                        <th>Unidad</th>
                        <th class="text-start">Descripción</th>
                        <th>Stock</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($i->idinsumo); ?></td>
                            <td class="text-start fw-semibold"><?php echo e($i->nombre); ?></td>
                            <td><?php echo e($i->unidad); ?></td>
                            <td class="text-start"><?php echo e(Str::limit($i->descripcion, 50, '…')); ?></td>
                            <td class="fw-bold text-success"><?php echo e(number_format($i->stock_actual, 2)); ?></td>
                            <td>
    <div class="d-flex justify-content-center gap-2">
        <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'insumos.edit')): ?>
            <a href="<?php echo e(route('insumos.edit', $i)); ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                <i class="bi bi-pencil-fill"></i>
            </a>
        <?php endif; ?>

        <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'insumos.delete')): ?>
            <form id="form-delete-<?php echo e($i->idinsumo); ?>" action="<?php echo e(route('insumos.destroy', $i)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="button" class="btn btn-sm btn-outline-danger"
                    onclick="confirmarEliminacion(<?php echo e($i->idinsumo); ?>)">
                    <i class="bi bi-trash-fill"></i>
                </button>
            </form>
        <?php endif; ?>
    </div>
</td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-4">No hay insumos registrados.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <?php if($insumos->hasPages()): ?>
        <div class="mt-4 d-flex justify-content-end">
            <?php echo e($insumos->onEachSide(1)->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmarEliminacion(id) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Este insumo será eliminado del sistema.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, eliminar',
        cancelButtonText: 'Cancelar',
        customClass: {
            title: 'fw-bold',
            confirmButton: 'px-4',
            cancelButton: 'px-4'
        }
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('form-delete-' + id).submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/insumos/index.blade.php ENDPATH**/ ?>