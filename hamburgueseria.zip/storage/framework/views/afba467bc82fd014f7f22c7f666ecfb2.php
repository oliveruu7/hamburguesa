

<?php $__env->startSection('title','Editar cliente'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="card shadow border-0">
    <div class="card-header bg-warning text-dark">
      <h5 class="mb-0"><i class="bi bi-pencil-fill me-2"></i> Editar cliente</h5>
    </div>
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('clientes.update', $cliente)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
          <label class="form-label fw-semibold">Nombre *</label>
          <input type="text" name="nombre" class="form-control" required maxlength="50" value="<?php echo e($cliente->nombre); ?>">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">CI *</label>
          <input type="text" name="ci" class="form-control" required maxlength="15" value="<?php echo e($cliente->ci); ?>">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Teléfono</label>
          <input type="text" name="telefono" class="form-control" maxlength="15" value="<?php echo e($cliente->telefono); ?>">
        </div>
        <div class="d-flex justify-content-end">
          <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary me-2">Cancelar</a>
          <button type="submit" class="btn btn-warning text-white">Actualizar</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/clientes/edit.blade.php ENDPATH**/ ?>