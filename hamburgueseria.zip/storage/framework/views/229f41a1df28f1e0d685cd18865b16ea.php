
<?php $__env->startSection('title','Lista de Roles'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  
  <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0" style="color:#6f42c1">
          <i class="bi bi-shield-lock-fill"></i> Lista de Roles
      </h3>
      <a href="<?php echo e(route('roles.create')); ?>" class="btn text-white"
         style="background:#6f42c1"><i class="bi bi-plus-circle"></i> Nuevo Rol</a>
  </div>

  
  <?php $__currentLoopData = ['success','error','info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(session($t)): ?>
        <div class="alert alert-<?php echo e($t=='success'?'success':($t=='error'?'danger':'warning')); ?>

                    alert-dismissible fade show">
            <?php echo e(session($t)); ?>

            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle bg-white shadow-sm">
      <thead class="text-center" style="background:#6f42c1;color:#fff">
        <tr><th>#</th><th>Nombre</th><th>Descripción</th><th>Estado</th><th>Acciones</th></tr>
      </thead>
      <tbody class="text-center">
        <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($rol->idrol); ?></td>
            <td><?php echo e($rol->nombre); ?></td>
            <td><?php echo e($rol->descripcion ?? 'Sin descripción'); ?></td>
            <td>
              <span class="badge <?php echo e($rol->estado?'bg-success':'bg-secondary'); ?>">
                  <?php echo e($rol->estado?'Activo':'Inactivo'); ?>

              </span>
            </td>
            <td>
              <a href="<?php echo e(route('roles.edit',$rol)); ?>" class="btn btn-sm text-white"
                 style="background:#6f42c1"><i class="bi bi-pencil-square"></i></a>

              <form action="<?php echo e(route('roles.destroy',$rol)); ?>" method="POST"
                    class="d-inline form-delete">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-danger"><i class="bi bi-trash-fill"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="5" class="text-muted">No hay roles registrados.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
setTimeout(()=>document.querySelectorAll('.alert').forEach(a=>{
  a.classList.remove('show');a.classList.add('fade');}),3000);

document.querySelectorAll('.form-delete').forEach(f=>{
  f.addEventListener('submit',e=>{
    e.preventDefault();
    Swal.fire({
      title:'¿Eliminar rol?',
      text:'Esta acción desactivará el rol.',
      icon:'warning',
      showCancelButton:true,
      confirmButtonColor:'#6f42c1',
      cancelButtonColor:'#6c757d',
      confirmButtonText:'Sí, eliminar',
      cancelButtonText:'Cancelar'
    }).then(r=>{ if(r.isConfirmed) f.submit(); });
  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/roles/index.blade.php ENDPATH**/ ?>