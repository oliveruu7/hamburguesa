<?php echo csrf_field(); ?>
<div class="row g-4">
    
    <div class="col-md-6">
        <label class="form-label fw-semibold">Nombre *</label>
        <input type="text" name="nombre" class="form-control" placeholder="Ej. Zombie Burger"
               value="<?php echo e(old('nombre',$product->nombre)); ?>" required>
    </div>

    
    <div class="col-md-6">
        <label class="form-label fw-semibold">Categoría *</label>
        <select name="idcategoria" class="form-select" required>
            <option value="">Seleccione…</option>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($c->idcategoria); ?>" <?php echo e($c->idcategoria==old('idcategoria',$product->idcategoria)?'selected':''); ?>>
                    <?php echo e($c->nombre); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    
    <div class="col-md-4">
        <label class="form-label fw-semibold">Presentación</label>
        <input type="text" name="tipo" class="form-control" placeholder="SIN | CON | COMBO"
               value="<?php echo e(old('tipo',$product->tipo)); ?>">
    </div>

    
    <div class="col-md-4">
        <label class="form-label fw-semibold">Precio (Bs) *</label>
        <input type="number" name="precio_unitario" step="0.01" min="0" class="form-control"
               value="<?php echo e(old('precio_unitario',$product->precio_unitario)); ?>" required>
    </div>

    
    <div class="col-md-4">
        <label class="form-label fw-semibold">Stock *</label>
        <input type="number" name="stock" min="0" class="form-control"
               value="<?php echo e(old('stock',$product->stock)); ?>" required>
    </div>

    
    <div class="col-12">
        <label class="form-label fw-semibold">Descripción</label>
        <textarea name="descripcion" rows="3" class="form-control" placeholder="Descripción breve…"><?php echo e(old('descripcion',$product->descripcion)); ?></textarea>
    </div>

    
    <div class="col-12">
        <label class="form-label fw-semibold">Imagen (URL)</label>
        <input type="url" name="imagenUrl" class="form-control" placeholder="https://...jpg"
               value="<?php echo e(old('imagenUrl',$product->imagenUrl)); ?>">
    </div>
</div>

<div class="text-end mt-4">
    <button class="btn btn-success px-4">
        <i class="bi bi-save me-1"></i> Guardar
    </button>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary">Cancelar</a>
</div><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/products/_form.blade.php ENDPATH**/ ?>