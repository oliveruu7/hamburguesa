
<?php $__env->startSection('title','Ventas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h2 class="fw-bold text-dark">
                <i class="bi bi-cart-check-fill me-2 text-success"></i> Ventas registradas
            </h2>
        </div>
        <div class="col-md-6 text-md-end">
            <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'sales.create')): ?>
                <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Nueva venta
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-1"></i>
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead class="table-success text-center">
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                        <th>Total (Bs)</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td><?php echo e($venta->idventa); ?></td>
                            <td><?php echo e($venta->cliente->nombre); ?></td>
                            <td><?php echo e($venta->usuario->nombre); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($venta->fecha_hora)->format('d/m/Y H:i')); ?></td>
                            <td class="text-success fw-bold">Bs <?php echo e(number_format($venta->total, 2)); ?></td>
                            <td>
                                <span class="badge <?php echo e($venta->estado ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($venta->estado ? 'Completada' : 'Anulada'); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('sales.show', $venta)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye-fill"></i>
                                </a>
                                <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'sales.edit')): ?>
                                    <a href="<?php echo e(route('sales.edit', $venta)); ?>" class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-pencil-fill"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No hay ventas registradas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="mt-3 d-flex justify-content-end">
        <?php echo e($ventas->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/sales/index.blade.php ENDPATH**/ ?>