
<?php $__env->startSection('title','Crear Rol'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
      <button class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('roles.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="card shadow border-0 mb-4">
      <div class="card-header" style="background:#6f42c1;color:#fff">
        <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i> Crear un Rol</h5>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label fw-semibold">Nombre *</label>
            <input name="nombre" class="form-control" required value="<?php echo e(old('nombre')); ?>">
          </div>
          <div class="col-md-8">
            <label class="form-label fw-semibold">Descripción</label>
            <input name="descripcion" class="form-control" value="<?php echo e(old('descripcion')); ?>">
          </div>
        </div>

        <h5 class="text-center my-3">Acceso completo</h5>
        <div class="d-flex justify-content-center gap-4 mb-2">
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="full_access"
                   value="yes" id="fa_yes" <?php echo e(old('full_access')=='yes'?'checked':''); ?>>
            <label class="form-check-label" for="fa_yes">Sí</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="full_access"
                   value="no" id="fa_no" <?php echo e(old('full_access','no')=='no'?'checked':''); ?>>
            <label class="form-check-label" for="fa_no">No</label>
          </div>
        </div>
      </div>
    </div>

    
    <div class="row g-3 mb-3">
      <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod=>$permisos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="card shadow-sm h-100">
            <div class="card-header fw-bold" style="background:#f8f9fa">
              <?php echo e(ucwords(str_replace('_',' ',$mod))); ?>

            </div>
            <div class="card-body" style="max-height:260px;overflow:auto">
              <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                  <input class="form-check-input perm" type="checkbox"
                         name="permisos[]" value="<?php echo e($p->idpermiso); ?>"
                         id="perm<?php echo e($p->idpermiso); ?>"
                         <?php echo e(in_array($p->idpermiso, old('permisos',[]))?'checked':''); ?>>
                  <label class="form-check-label small text-muted" for="perm<?php echo e($p->idpermiso); ?>">
                    <?php echo e($p->nombre); ?> <?php if($p->descripcion): ?><em>(<?php echo e($p->descripcion); ?>)</em><?php endif; ?>
                  </label>
                </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <button class="btn text-white" style="background:#6f42c1">
        <i class="bi bi-save2"></i> Guardar
    </button>
    <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Cancelar</a>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
const yes=document.getElementById('fa_yes');
const no=document.getElementById('fa_no');
const cb=document.querySelectorAll('.perm');
function toggle(d){ cb.forEach(x=>{x.disabled=d; if(d) x.checked=true;}); }
toggle(yes && yes.checked);
yes&&yes.addEventListener('change',()=>toggle(true));
no &&no .addEventListener('change',()=>toggle(false));
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/roles/create.blade.php ENDPATH**/ ?>