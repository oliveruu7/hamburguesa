
<?php $__env->startSection('title','Productos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h2 class="fw-bold text-dark">
                <i class="bi bi-box-seam me-2 text-primary"></i> Productos registrados
            </h2>
        </div>
        <div class="col-md-6 text-md-end">
            <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'products.create')): ?>
                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-success shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Nuevo producto
                </a>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="row mb-3">
        <div class="col-md-12">
        <form method="GET" class="input-group shadow-sm">
           <button type="submit" class="btn btn-outline-secondary">
           <i class="bi bi-search"></i>
           </button>
          <input name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Buscar por nombre o categoría…">
            <?php if(request('q')): ?>
              <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-danger">Limpiar</a>
            <?php endif; ?>
        </form>
        </div>
    </div>

    
    <?php $__currentLoopData = ['success', 'error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($msg)): ?>
            <div class="alert alert-<?php echo e($msg == 'success' ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert">
                <?php echo e(session($msg)); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Cerrar"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle text-center">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Imagen</th>
                        <th>Nombre</th>
                        <th>Categoría</th>
                        <th>Descripción</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($p->idhamburguesa); ?></td>
                            <td>
                                <img src="<?php echo e($p->imagenUrl ?? 'https://via.placeholder.com/60x45?text=Img'); ?>"
                                     class="img-thumbnail"
                                     style="width: 60px; height: 45px; object-fit: cover;">
                            </td>
                            <td class="text-start fw-semibold"><?php echo e($p->nombre); ?></td>
                            <td><?php echo e($p->categoria->nombre ?? '-'); ?></td>
                            <td class="text-start"><?php echo e(Str::limit($p->descripcion, 50, '…')); ?></td>
                            <td class="text-end fw-bold text-success">Bs <?php echo e(number_format($p->precio_unitario, 2)); ?></td>
                            <td>
                                <div class="d-flex justify-content-center gap-1">
                                    <a href="<?php echo e(route('products.show', $p)); ?>" class="btn btn-sm btn-outline-primary" title="Ver">
                                        <i class="bi bi-eye-fill"></i>
                                    </a>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'products.edit')): ?>
                                        <a href="<?php echo e(route('products.edit', $p)); ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'products.delete')): ?>
                                    <form id="form-delete-<?php echo e($p->idhamburguesa); ?>" action="<?php echo e(route('products.destroy', $p)); ?>" method="POST" class="d-inline">
                                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                      <button type="button" class="btn btn-sm btn-outline-danger" title="Eliminar"
                                        onclick="confirmarEliminacion(<?php echo e($p->idhamburguesa); ?>)">
                                        <i class="bi bi-trash-fill"></i>
                                      </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No se encontraron productos</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="mt-3 d-flex justify-content-end">
        <?php echo e($products->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmarEliminacion(id) {
    Swal.fire({
        title: '¿Estás seguro?',
        text: "Este producto será desactivado.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#e3342f',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Sí, desactivar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('form-delete-' + id).submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/products/index.blade.php ENDPATH**/ ?>