
<?php $__env->startSection('title', 'Registrar nuevo insumo'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  
  <?php $__currentLoopData = ['success', 'error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session($type)): ?>
      <div class="alert alert-<?php echo e($type == 'success' ? 'success' : 'danger'); ?> alert-dismissible fade show">
        <i class="bi <?php echo e($type == 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'); ?>"></i>
        <?php echo e(session($type)); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Corrige los siguientes errores:</strong>
      <ul class="mb-0 mt-2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($err); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  
  <div class="card shadow border-0">
    <div class="card-header text-white" style="background:#00bcd4;">
      <h5 class="mb-0"><i class="bi bi-plus-circle-fill me-2"></i> Crear nuevo insumo</h5>
    </div>

    <div class="card-body">
      <form id="formInsumo" method="POST" action="<?php echo e(route('insumos.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <div class="row g-3">

          
          <div class="col-md-6">
            <label class="form-label fw-semibold"><i class="bi bi-tag-fill"></i> Nombre <span class="text-danger">*</span></label>
            <input name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control" maxlength="50" required pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ 0-9]+" autocomplete="off">
            <div class="invalid-feedback">Campo requerido. Máx. 50 caracteres alfanuméricos.</div>
          </div>

          
          <div class="col-md-6">
            <label class="form-label fw-semibold"><i class="bi bi-boxes"></i> Unidad de medida <span class="text-danger">*</span></label>
            <input name="unidad" value="<?php echo e(old('unidad')); ?>" class="form-control" maxlength="20" required>
            <div class="invalid-feedback">Campo requerido. Máx. 20 caracteres.</div>
          </div>

          
          <div class="col-md-12">
            <label class="form-label fw-semibold"><i class="bi bi-card-text"></i> Descripción (opcional)</label>
            <textarea name="descripcion" class="form-control" rows="3" maxlength="255"><?php echo e(old('descripcion')); ?></textarea>
            <div class="invalid-feedback">Máx. 255 caracteres.</div>
          </div>
        </div>

        
        <div class="mt-4 d-flex justify-content-between">
          <a href="<?php echo e(route('insumos.index')); ?>" class="btn btn-secondary px-4">
            <i class="bi bi-x-circle-fill me-1"></i> Cancelar
          </a>
          <button id="btnGuardar" class="btn btn-primary px-4 opacity-50" disabled>
            <i class="bi bi-save-fill me-1"></i> Guardar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
const form = document.getElementById('formInsumo');
const btn  = document.getElementById('btnGuardar');

// Validación reactiva
form.addEventListener('input', () => {
  const isValid = form.checkValidity();
  btn.disabled = !isValid;
  btn.classList.toggle('opacity-50', !isValid);
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/insumos/create.blade.php ENDPATH**/ ?>