<?php
// app/Http/Controllers/InsumoController.php
namespace App\Http\Controllers;

use App\Http\Middleware\CheckPermission as Perm; 
use App\Models\Insumo;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;


class InsumoController extends Controller
{
    # Middleware para controlar el acceso
    public function __construct()
    {
        $this->middleware(Perm::class . ':insumos.index')->only('index');
        $this->middleware(Perm::class . ':insumos.create')->only(['create','store']);
        $this->middleware(Perm::class . ':insumos.edit')->only(['edit','update']);
        $this->middleware(Perm::class . ':insumos.delete')->only('destroy');
    }

    # funcion para listar los insumos
    public function index(Request $request)
    {
        $query = Insumo::query();

        if ($request->filled('q')) {
            $q = trim($request->q);
            $query->where('nombre', 'LIKE', "%$q%")
                  ->orWhere('unidad', 'LIKE', "%$q%");
        }

        $insumos = $query->orderBy('nombre')->paginate(10);
        return view('insumos.index', compact('insumos'));
    }

    # funciones para crear, editar, actualizar y eliminar insumos
    public function create()
    {
        return view('insumos.create', ['insumo' => new Insumo()]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nombre'     => 'required|string|max:50|unique:insumo,nombre',
            'unidad'     => 'required|string|max:20',
            'descripcion'=> 'nullable|string|max:255'
        ]);

        $data['stock_actual'] = 0.00;

        Insumo::create($data);
        return redirect()->route('insumos.index')->with('success', 'Insumo registrado exitosamente.');
    }
    # Editar insumo
    # Actualizar insumo

    public function edit(Insumo $insumo)
    {
        return view('insumos.edit', compact('insumo'));
    }

    public function update(Request $request, Insumo $insumo)
    {
        $data = $request->validate([
            'nombre'      => 'required|string|max:50|unique:insumo,nombre,' . $insumo->idinsumo . ',idinsumo',
            'unidad'      => 'required|string|max:20',
            'descripcion' => 'nullable|string|max:255'
        ]);

        if (!$insumo->isDirty($data)) {
            return back()->with('info', 'No se realizaron cambios.');
        }

        $insumo->update($data);
        return redirect()->route('insumos.index')->with('success', 'Insumo actualizado correctamente.');
    }
    # Eliminar insumo

    public function destroy(Insumo $insumo)
    {
        $insumo->delete();
        return back()->with('success', 'Insumo eliminado.');
    }
}
