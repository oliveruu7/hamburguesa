<?php
// ACTUALIZADO - SaleController.php

namespace App\Http\Controllers;

use App\Models\Venta;
use App\Models\Cliente;
use App\Models\Product;
use App\Models\DetalleVenta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Middleware\CheckPermission as Perm;

class SaleController extends Controller
{
    public function __construct()
    {
        $this->middleware(Perm::class . ':sales.index')->only('index');
        $this->middleware(Perm::class . ':sales.create')->only(['create', 'store']);
        $this->middleware(Perm::class . ':sales.edit')->only(['edit', 'update']);
        $this->middleware(Perm::class . ':sales.delete')->only('destroy');
    }

    public function index()
    {
        $ventas = Venta::with(['cliente', 'usuario'])
                        ->orderByDesc('fecha_hora')
                        ->paginate(10);

        return view('sales.index', compact('ventas'));
    }

    public function create()
    {
        return view('sales.create', [
            'clientes' => Cliente::orderBy('nombre')->get(),
            'productos' => Product::where('estado', 1)->get()
        ]);
    }

    public function store(Request $request)
    {
        $productos = $request->input('productos', []);

        if (empty($productos)) {
            return back()->withInput()->with('error', 'Debe agregar al menos un producto.');
        }

        // Validaciones manuales debido a estructura personalizada
        foreach ($productos as $i => $item) {
            if (!isset($item['idproducto']) || !isset($item['cantidad']) || !isset($item['precio_unitario'])) {
                return back()->withInput()->with('error', "Producto #$i está incompleto.");
            }
            if (!is_numeric($item['cantidad']) || $item['cantidad'] < 1) {
                return back()->withInput()->with('error', "Cantidad inválida en producto #$i.");
            }
            if (!is_numeric($item['precio_unitario']) || $item['precio_unitario'] < 0) {
                return back()->withInput()->with('error', "Precio inválido en producto #$i.");
            }
        }

        try {
            DB::beginTransaction();

            $total = collect($productos)->sum(function ($item) {
                return $item['precio_unitario'] * $item['cantidad'];
            });

            $venta = Venta::create([
                'idcliente' => $request->idcliente,
                'idusuario' => Auth::id(),
                'fecha_hora' => now(),
                'total' => $total
            ]);

            foreach ($productos as $item) {
                DetalleVenta::create([
                    'idventa' => $venta->idventa,
                    'idproducto' => $item['idproducto'],
                    'cantidad' => $item['cantidad'],
                    'precio_unitario' => $item['precio_unitario'],
                    'subtotal' => $item['cantidad'] * $item['precio_unitario'],
                ]);
            }

            DB::commit();
            return redirect()->route('sales.index')->with('success', 'Venta registrada correctamente.');

        } catch (\Throwable $e) {
            DB::rollBack();
            return back()->withInput()->with('error', 'Error al registrar la venta: ' . $e->getMessage());
        }
    }

    public function show(Venta $venta)
    {
        $venta->load(['cliente', 'detalles.producto']);
        return view('sales.show', compact('venta'));
    }

    public function destroy(Venta $venta)
    {
        $venta->delete();
        return back()->with('success', 'Venta eliminada.');
    }
}
