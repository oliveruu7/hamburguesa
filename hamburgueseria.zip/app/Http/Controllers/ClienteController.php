<?php

namespace App\Http\Controllers;

use App\Http\Middleware\CheckPermission as Perm;
use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    public function __construct()
    {
        $this->middleware(Perm::class . ':clientes.index')->only('index');
        $this->middleware(Perm::class . ':clientes.create')->only(['create', 'store']);
        $this->middleware(Perm::class . ':clientes.edit')->only(['edit', 'update']);
        $this->middleware(Perm::class . ':clientes.delete')->only('destroy');
    }

    public function index()
    {
        $clientes = Cliente::orderBy('nombre')->paginate(10);
        return view('clientes.index', compact('clientes'));
    }

    public function create()
    {
        return view('clientes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre'   => 'required|regex:/^[a-zA-Z\s]+$/u|max:25',
            'ci'       => 'required|digits_between:7,8',
            'telefono' => 'nullable|digits_between:7,8',
        ]);

        Cliente::create($request->all());

        return redirect()->route('clientes.index')->with('success', 'Cliente registrado correctamente.');
    }

    public function edit(Cliente $cliente)
    {
        return view('clientes.edit', compact('cliente'));
    }

    public function update(Request $request, Cliente $cliente)
    {
        $request->validate([
            'nombre'   => 'required|regex:/^[a-zA-Z\s]+$/u|max:25',
            'ci'       => 'required|digits_between:7,8',
            'telefono' => 'nullable|digits_between:7,8',
        ]);

        $cliente->update($request->all());

        return redirect()->route('clientes.index')->with('success', 'Cliente actualizado correctamente.');
    }

    public function destroy(Cliente $cliente)
    {
        $cliente->delete();
        return redirect()->route('clientes.index')->with('success', 'Cliente eliminado correctamente.');
    }
}
