<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Insumo extends Model
{
    protected $table = 'insumo';
    protected $primaryKey = 'idinsumo';
    public $timestamps = false;

    protected $fillable = [
        'nombre', 'unidad', 'descripcion', 'stock_actual'
    ];
}