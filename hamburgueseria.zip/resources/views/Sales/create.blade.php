@extends('layouts.admin')
@section('title','Registrar Venta')

@section('content')
<div class="container py-4">
  <form action="{{ route('sales.store') }}" method="POST" id="formVenta">
    @csrf

    <!-- Datos del cliente -->
    <div class="card shadow border-0 mb-4">
      <div class="card-header bg-success text-white">
        <h5 class="mb-0"><i class="bi bi-person-fill me-2"></i> Datos del Cliente</h5>
      </div>
      <div class="card-body">
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label fw-semibold">Cliente <span class="text-danger">*</span></label>
            <select name="idcliente" class="form-select" required>
              <option value="">Seleccione…</option>
              @foreach($clientes as $cliente)
                <option value="{{ $cliente->idcliente }}">{{ $cliente->nombre }}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>
    </div>

    <!-- Detalle de productos -->
    <div class="card shadow border-0 mb-4">
      <div class="card-header bg-primary text-white d-flex justify-content-between">
        <span><i class="bi bi-box-seam me-2"></i> Productos</span>
        <button type="button" class="btn btn-light btn-sm" onclick="agregarProducto()">
          <i class="bi bi-plus-circle"></i> Agregar producto
        </button>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered align-middle mb-0" id="tablaDetalle">
            <thead class="table-light text-center">
              <tr>
                <th>Producto</th>
                <th>Precio (Bs)</th>
                <th>Cantidad</th>
                <th>Subtotal</th>
                <th></th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Botones -->
    <div class="text-end">
      <a href="{{ route('sales.index') }}" class="btn btn-secondary px-4">
        <i class="bi bi-x-circle"></i> Cancelar
      </a>
      <button type="submit" class="btn btn-success px-4">
        <i class="bi bi-check-circle"></i> Confirmar venta
      </button>
    </div>
  </form>
</div>
@endsection

@push('js')
<script>
const productos = @json($productos);

function agregarProducto() {
  const tbody = document.querySelector('#tablaDetalle tbody');
  const index = tbody.rows.length;

  const row = document.createElement('tr');
  row.innerHTML = `
    <td>
      <select name="productos[${index}][idproducto]" class="form-select" onchange="setPrecio(this)">
        <option value="">Seleccione</option>
        ${productos.map(p => `<option value="${p.idproducto}" data-precio="${p.precio_unitario}">${p.nombre}</option>`).join('')}
      </select>
    </td>
    <td><input type="number" class="form-control text-end" name="productos[${index}][precio_unitario]" readonly></td>
    <td><input type="number" class="form-control text-end" name="productos[${index}][cantidad]" min="1" value="1" onchange="calcularSubtotal(this)"></td>
    <td><input type="text" class="form-control text-end" readonly></td>
    <td><button type="button" class="btn btn-sm btn-danger" onclick="this.closest('tr').remove(); calcularTotal();">✖</button></td>
  `;
  tbody.appendChild(row);
}

function setPrecio(select) {
  const precio = select.options[select.selectedIndex].dataset.precio;
  const row = select.closest('tr');
  row.querySelector('[name$="[precio_unitario]"]').value = precio;
  calcularSubtotal(row.querySelector('[name$="[cantidad]"]'));
}

function calcularSubtotal(input) {
  const row = input.closest('tr');
  const cantidad = parseFloat(input.value);
  const precio = parseFloat(row.querySelector('[name$="[precio_unitario]"]').value);
  const subtotal = cantidad * precio;
  row.querySelector('td:nth-child(4) input').value = subtotal.toFixed(2);
  calcularTotal();
}

function calcularTotal() {
  let total = 0;
  document.querySelectorAll('#tablaDetalle tbody tr').forEach(row => {
    total += parseFloat(row.querySelector('td:nth-child(4) input').value) || 0;
  });
  // Se podría mostrar el total aquí si se quiere
}
</script>
@endpush
