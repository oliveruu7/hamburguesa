@extends('layouts.admin')
@section('title','Ventas')

@section('content')
<div class="container-fluid">

    {{-- Encabezado --}}
    <div class="row align-items-center mb-4">
        <div class="col-md-6">
            <h2 class="fw-bold text-dark">
                <i class="bi bi-cart-check-fill me-2 text-success"></i> Ventas registradas
            </h2>
        </div>
        <div class="col-md-6 text-md-end">
            @permiso('sales.create')
                <a href="{{ route('sales.create') }}" class="btn btn-primary shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Nueva venta
                </a>
            @endpermiso
        </div>
    </div>

    {{-- Mensaje flash --}}
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-1"></i>
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    {{-- Tabla de ventas --}}
    <div class="card border-0 shadow-sm">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead class="table-success text-center">
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Usuario</th>
                        <th>Fecha</th>
                        <th>Total (Bs)</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($ventas as $venta)
                        <tr class="text-center">
                            <td>{{ $venta->idventa }}</td>
                            <td>{{ $venta->cliente->nombre }}</td>
                            <td>{{ $venta->usuario->nombre }}</td>
                            <td>{{ \Carbon\Carbon::parse($venta->fecha_hora)->format('d/m/Y H:i') }}</td>
                            <td class="text-success fw-bold">Bs {{ number_format($venta->total, 2) }}</td>
                            <td>
                                <span class="badge {{ $venta->estado ? 'bg-success' : 'bg-secondary' }}">
                                    {{ $venta->estado ? 'Completada' : 'Anulada' }}
                                </span>
                            </td>
                            <td>
                                <a href="{{ route('sales.show', $venta) }}" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye-fill"></i>
                                </a>
                                @permiso('sales.edit')
                                    <a href="{{ route('sales.edit', $venta) }}" class="btn btn-sm btn-outline-warning">
                                        <i class="bi bi-pencil-fill"></i>
                                    </a>
                                @endpermiso
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">No hay ventas registradas.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    {{-- Paginación --}}
    <div class="mt-3 d-flex justify-content-end">
        {{ $ventas->links() }}
    </div>

</div>
@endsection
