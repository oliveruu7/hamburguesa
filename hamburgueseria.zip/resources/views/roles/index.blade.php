@extends('layouts.admin')
@section('title','Lista de Roles')

@section('content')
<div class="container py-4">
  {{-- encabezado --}}
  <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0" style="color:#6f42c1">
          <i class="bi bi-shield-lock-fill"></i> Lista de Roles
      </h3>
      <a href="{{ route('roles.create') }}" class="btn text-white"
         style="background:#6f42c1"><i class="bi bi-plus-circle"></i> Nuevo Rol</a>
  </div>

  {{-- alertas --}}
  @foreach(['success','error','info'] as $t)
      @if(session($t))
        <div class="alert alert-{{ $t=='success'?'success':($t=='error'?'danger':'warning') }}
                    alert-dismissible fade show">
            {{ session($t) }}
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      @endif
  @endforeach

  {{-- tabla --}}
  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle bg-white shadow-sm">
      <thead class="text-center" style="background:#6f42c1;color:#fff">
        <tr><th>#</th><th>Nombre</th><th>Descripción</th><th>Estado</th><th>Acciones</th></tr>
      </thead>
      <tbody class="text-center">
        @forelse($roles as $rol)
          <tr>
            <td>{{ $rol->idrol }}</td>
            <td>{{ $rol->nombre }}</td>
            <td>{{ $rol->descripcion ?? 'Sin descripción' }}</td>
            <td>
              <span class="badge {{ $rol->estado?'bg-success':'bg-secondary' }}">
                  {{ $rol->estado?'Activo':'Inactivo' }}
              </span>
            </td>
            <td>
              <a href="{{ route('roles.edit',$rol) }}" class="btn btn-sm text-white"
                 style="background:#6f42c1"><i class="bi bi-pencil-square"></i></a>

              <form action="{{ route('roles.destroy',$rol) }}" method="POST"
                    class="d-inline form-delete">
                  @csrf @method('DELETE')
                  <button class="btn btn-sm btn-danger"><i class="bi bi-trash-fill"></i></button>
              </form>
            </td>
          </tr>
        @empty
          <tr><td colspan="5" class="text-muted">No hay roles registrados.</td></tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection

@push('js')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
setTimeout(()=>document.querySelectorAll('.alert').forEach(a=>{
  a.classList.remove('show');a.classList.add('fade');}),3000);

document.querySelectorAll('.form-delete').forEach(f=>{
  f.addEventListener('submit',e=>{
    e.preventDefault();
    Swal.fire({
      title:'¿Eliminar rol?',
      text:'Esta acción desactivará el rol.',
      icon:'warning',
      showCancelButton:true,
      confirmButtonColor:'#6f42c1',
      cancelButtonColor:'#6c757d',
      confirmButtonText:'Sí, eliminar',
      cancelButtonText:'Cancelar'
    }).then(r=>{ if(r.isConfirmed) f.submit(); });
  });
});
</script>
@endpush
