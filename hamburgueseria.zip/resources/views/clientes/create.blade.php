@extends('layouts.admin')
@section('title','Nuevo cliente')

@section('content')
<div class="container py-4">
  <div class="card shadow border-0">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0"><i class="bi bi-person-plus-fill me-2"></i> Registrar nuevo cliente</h5>
    </div>
    <div class="card-body">
      <form method="POST" action="{{ route('clientes.store') }}">
        @csrf

        <div class="form-floating mb-3">
          <input type="text" name="nombre" class="form-control @error('nombre') is-invalid @enderror"
                 value="{{ old('nombre') }}" maxlength="25" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" required placeholder="Nombre">
          <label>Nombre *</label>
          @error('nombre') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="form-floating mb-3">
          <input type="text" name="ci" class="form-control @error('ci') is-invalid @enderror"
                 value="{{ old('ci') }}" maxlength="8" minlength="7" pattern="\d{7,8}" required placeholder="CI">
          <label>CI *</label>
          @error('ci') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="form-floating mb-3">
          <input type="text" name="telefono" class="form-control @error('telefono') is-invalid @enderror"
                 value="{{ old('telefono') }}" maxlength="8" minlength="7" pattern="\d{7,8}" placeholder="Teléfono">
          <label>Teléfono</label>
          @error('telefono') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="d-flex justify-content-end">
          <a href="{{ route('clientes.index') }}" class="btn btn-secondary me-2">Cancelar</a>
          <button type="submit" class="btn btn-success">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>
@endsection
