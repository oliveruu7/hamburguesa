
@extends('layouts.admin')
@section('title','Editar cliente')

@section('content')
<div class="container py-4">
  <div class="card shadow border-0">
    <div class="card-header bg-warning text-dark">
      <h5 class="mb-0"><i class="bi bi-pencil-fill me-2"></i> Editar cliente</h5>
    </div>
    <div class="card-body">
      <form method="POST" action="{{ route('clientes.update', $cliente) }}">
        @csrf @method('PUT')
        <div class="mb-3">
          <label class="form-label fw-semibold">Nombre *</label>
          <input type="text" name="nombre" class="form-control" required maxlength="50" value="{{ $cliente->nombre }}">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">CI *</label>
          <input type="text" name="ci" class="form-control" required maxlength="15" value="{{ $cliente->ci }}">
        </div>
        <div class="mb-3">
          <label class="form-label fw-semibold">Teléfono</label>
          <input type="text" name="telefono" class="form-control" maxlength="15" value="{{ $cliente->telefono }}">
        </div>
        <div class="d-flex justify-content-end">
          <a href="{{ route('clientes.index') }}" class="btn btn-secondary me-2">Cancelar</a>
          <button type="submit" class="btn btn-warning text-white">Actualizar</button>
        </div>
      </form>
    </div>
  </div>
</div>
@endsection
