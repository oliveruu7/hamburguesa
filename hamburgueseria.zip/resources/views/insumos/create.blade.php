@extends('layouts.admin')
@section('title', 'Registrar nuevo insumo')

@section('content')
<div class="container py-4">

  {{-- Alertas --}}
  @foreach (['success', 'error'] as $type)
    @if(session($type))
      <div class="alert alert-{{ $type == 'success' ? 'success' : 'danger' }} alert-dismissible fade show">
        <i class="bi {{ $type == 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill' }}"></i>
        {{ session($type) }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    @endif
  @endforeach

  {{-- Errores de validación --}}
  @if($errors->any())
    <div class="alert alert-danger alert-dismissible fade show">
      <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Corrige los siguientes errores:</strong>
      <ul class="mb-0 mt-2">
        @foreach ($errors->all() as $err)
          <li>{{ $err }}</li>
        @endforeach
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  @endif

  {{-- Formulario --}}
  <div class="card shadow border-0">
    <div class="card-header text-white" style="background:#00bcd4;">
      <h5 class="mb-0"><i class="bi bi-plus-circle-fill me-2"></i> Crear nuevo insumo</h5>
    </div>

    <div class="card-body">
      <form id="formInsumo" method="POST" action="{{ route('insumos.store') }}" novalidate>
        @csrf
        <div class="row g-3">

          {{-- Nombre --}}
          <div class="col-md-6">
            <label class="form-label fw-semibold"><i class="bi bi-tag-fill"></i> Nombre <span class="text-danger">*</span></label>
            <input name="nombre" value="{{ old('nombre') }}" class="form-control" maxlength="50" required pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ 0-9]+" autocomplete="off">
            <div class="invalid-feedback">Campo requerido. Máx. 50 caracteres alfanuméricos.</div>
          </div>

          {{-- Unidad --}}
          <div class="col-md-6">
            <label class="form-label fw-semibold"><i class="bi bi-boxes"></i> Unidad de medida <span class="text-danger">*</span></label>
            <input name="unidad" value="{{ old('unidad') }}" class="form-control" maxlength="20" required>
            <div class="invalid-feedback">Campo requerido. Máx. 20 caracteres.</div>
          </div>

          {{-- Descripción --}}
          <div class="col-md-12">
            <label class="form-label fw-semibold"><i class="bi bi-card-text"></i> Descripción (opcional)</label>
            <textarea name="descripcion" class="form-control" rows="3" maxlength="255">{{ old('descripcion') }}</textarea>
            <div class="invalid-feedback">Máx. 255 caracteres.</div>
          </div>
        </div>

        {{-- Botones --}}
        <div class="mt-4 d-flex justify-content-between">
          <a href="{{ route('insumos.index') }}" class="btn btn-secondary px-4">
            <i class="bi bi-x-circle-fill me-1"></i> Cancelar
          </a>
          <button id="btnGuardar" class="btn btn-primary px-4 opacity-50" disabled>
            <i class="bi bi-save-fill me-1"></i> Guardar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
@endsection

@push('js')
<script>
const form = document.getElementById('formInsumo');
const btn  = document.getElementById('btnGuardar');

// Validación reactiva
form.addEventListener('input', () => {
  const isValid = form.checkValidity();
  btn.disabled = !isValid;
  btn.classList.toggle('opacity-50', !isValid);
});
</script>
@endpush
