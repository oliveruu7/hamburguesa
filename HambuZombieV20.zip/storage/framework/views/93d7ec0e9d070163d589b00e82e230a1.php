 
<?php $__env->startSection('title', 'Editar Receta'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  <h3 class="text-primary mb-4">
    <i class="bi bi-pencil-square me-2"></i> Editar Receta
  </h3>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show">
      <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Corrige los siguientes errores:</strong>
      <ul class="mt-2 mb-0">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('recetas.update', $receta)); ?>" method="POST" class="card shadow border-0">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="card-body row g-3">

      
      <div class="col-md-6">
        <label class="form-label fw-semibold">Hamburguesa <span class="text-danger">*</span></label>
        <select name="idhamburguesa" class="form-select" required disabled>
          <option value="">-- Selecciona --</option>
          <?php $__currentLoopData = $hamburguesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($h->idhamburguesa); ?>" <?php echo e($receta->idhamburguesa == $h->idhamburguesa ? 'selected' : ''); ?>>
              <?php echo e($h->nombre); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="hidden" name="idhamburguesa" value="<?php echo e($receta->idhamburguesa); ?>">
      </div>

      
      <div class="col-md-6">
        <label class="form-label fw-semibold">Insumo <span class="text-danger">*</span></label>
        <select name="idinsumo" class="form-select" required disabled>
          <option value="">-- Selecciona --</option>
          <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($i->idinsumo); ?>" <?php echo e($receta->idinsumo == $i->idinsumo ? 'selected' : ''); ?>>
              <?php echo e($i->nombre); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="hidden" name="idinsumo" value="<?php echo e($receta->idinsumo); ?>">
      </div>

      
      <div class="col-md-6">
        <label class="form-label fw-semibold">Cantidad Necesaria <span class="text-danger">*</span></label>
        <input type="number" name="cantidad_necesaria" class="form-control" step="0.01" min="0.01"
               value="<?php echo e(old('cantidad_necesaria', $receta->cantidad_necesaria)); ?>" required>
      </div>

    </div>

    <div class="card-footer d-flex justify-content-between mt-4">
      <a href="<?php echo e(route('recetas.index')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle me-1"></i> Cancelar
      </a>
      <button type="submit" class="btn btn-primary">
        <i class="bi bi-save-fill me-1"></i> Guardar Cambios
      </button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/recetas/edit.blade.php ENDPATH**/ ?>