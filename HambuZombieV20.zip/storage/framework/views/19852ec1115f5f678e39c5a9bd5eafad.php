 
<?php $__env->startSection('title', 'Editar compra #'.$compra->idcompra); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  
  <h3 class="mb-3" style="color:#008080">
    <i class="bi bi-pencil-square me-1"></i> Editar Compra #<?php echo e($compra->idcompra); ?>

  </h3>

  
  <?php $__currentLoopData = ['success','error','info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(session($t)): ?>
          <div class="alert alert-<?php echo e($t=='success'?'success':($t=='error'?'danger':'warning')); ?>">
              <?php echo e(session($t)); ?>

          </div>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <form id="formCompra" action="<?php echo e(route('compras.update',$compra)); ?>" method="POST">
      <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

      
      <div class="mb-3">
          <label class="fw-bold" style="color:#008080">Proveedor</label>
          <select name="idproveedor" class="form-select" required>
              <option value="">-- seleccione --</option>
              <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($p->idproveedor); ?>"
                          <?php echo e($p->idproveedor==$compra->idproveedor?'selected':''); ?>>
                      <?php echo e($p->nombre); ?>

                  </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>

      
      <table class="table table-bordered" id="tablaInsumos">
          <thead style="background:#008080;color:#fff" class="text-center">
              <tr>
                  <th>Insumo</th>
                  <th>Cantidad</th>
                  <th>Precio</th>
                  <th>Subtotal</th>
                  <th>
                      <button type="button" class="btn btn-light btn-sm fw-bold"
                              onclick="agregarFila()">+</button>
                  </th>
              </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $compra->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx=>$d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td>
                      <select name="detalles[<?php echo e($idx); ?>][idinsumo]" class="form-select" required>
                          <option value="">--</option>
                          <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($i->idinsumo); ?>"
                                  <?php echo e($i->idinsumo==$d->idinsumo?'selected':''); ?>>
                                  <?php echo e($i->nombre); ?>

                              </option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                  </td>
                  <td>
                      <input type="number" step="0.01"
                             name="detalles[<?php echo e($idx); ?>][cantidad]"
                             class="form-control" value="<?php echo e($d->cantidad); ?>"
                             oninput="recalcular()" required>
                  </td>
                  <td>
                      <input type="number" step="0.01"
                             name="detalles[<?php echo e($idx); ?>][precio]"
                             class="form-control" value="<?php echo e($d->precio); ?>"
                             oninput="recalcular()" required>
                  </td>
                  <td class="subtotal">0.00</td>
                  <td>
                      <button type="button" class="btn btn-outline-danger btn-sm"
                              onclick="this.closest('tr').remove(); recalcular();">−</button>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>

      
      <div class="text-end mb-4">
          <strong style="color:#008080">Total: <span id="totalMostrar">0.00</span> Bs</strong>
          <input type="hidden" name="total" id="total">
      </div>

      
      <div class="d-flex justify-content-between">
          <a href="<?php echo e(route('compras.index')); ?>" class="btn btn-secondary">
              <i class="bi bi-arrow-left"></i> Volver
          </a>
          <button class="btn text-white" style="background:#008080">
              <i class="bi bi-save me-1"></i> Guardar cambios
          </button>
      </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
const insumos = <?php echo json_encode($insumos, 15, 512) ?>;

/* Ajusta subtotales al cargar */
document.addEventListener('DOMContentLoaded', () => recalcular());

function agregarFila(){
    const idx = document.querySelectorAll('#tablaInsumos tbody tr').length;
    const fila = `
    <tr>
      <td>
        <select name="detalles[${idx}][idinsumo]" class="form-select" required>
          <option value="">--</option>
          ${insumos.map(i=>`<option value="${i.idinsumo}">${i.nombre}</option>`).join('')}
        </select>
      </td>
      <td><input type="number" step="0.01" name="detalles[${idx}][cantidad]" class="form-control" oninput="recalcular()" required></td>
      <td><input type="number" step="0.01" name="detalles[${idx}][precio]"   class="form-control" oninput="recalcular()" required></td>
      <td class="subtotal">0.00</td>
      <td><button type="button" class="btn btn-outline-danger btn-sm" onclick="this.closest('tr').remove(); recalcular();">−</button></td>
    </tr>`;
    document.querySelector('#tablaInsumos tbody').insertAdjacentHTML('beforeend', fila);
}

function recalcular(){
    let total=0;
    document.querySelectorAll('#tablaInsumos tbody tr').forEach(tr=>{
        const c=parseFloat(tr.querySelector('[name*="[cantidad]"]').value)||0;
        const p=parseFloat(tr.querySelector('[name*="[precio]"]').value)||0;
        const sub=c*p;
        tr.querySelector('.subtotal').textContent=sub.toFixed(2);
        total+=sub;
    });
    document.getElementById('totalMostrar').textContent=total.toFixed(2);
    document.getElementById('total').value=total.toFixed(2);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/compras/edit.blade.php ENDPATH**/ ?>