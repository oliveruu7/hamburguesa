 
<?php $__env->startSection('title','Detalle Producto'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <div class="mb-3">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-secondary shadow-sm">
            <i class="bi bi-arrow-left-circle me-1"></i> Volver 
        </a>
    </div>

    
    <div class="card shadow border-0">
        <div class="row g-0">
            
            <div class="col-lg-5">
                <img src="<?php echo e($product->imagenUrl ?? 'https://via.placeholder.com/600x400?text=Sin+Imagen'); ?>"
                     alt="Imagen del producto"
                     class="img-fluid rounded-start w-100 h-100 object-fit-cover"
                     style="object-fit: cover;">
            </div>

            
            <div class="col-lg-7">
                <div class="card-body p-4">
                    <h3 class="fw-bold text-primary mb-3">
                        <i class="bi bi-box-seam me-2"></i> <?php echo e($product->nombre); ?>

                    </h3>

                    <div class="mb-3">
                        <span class="text-muted fw-semibold">
                            <i class="bi bi-tags-fill me-1"></i> Categoría:
                        </span>
                        <span class="fw-bold"><?php echo e($product->categoria->nombre); ?></span>
                    </div>

                    <div class="mb-3">
                        <span class="text-muted fw-semibold">
                            <i class="bi bi-currency-dollar me-1"></i> Precio:
                        </span>
                        <span class="text-success fw-bold">Bs <?php echo e(number_format($product->precio_unitario, 2)); ?></span>
                    </div>

                    <hr>

                    <h6 class="text-muted"><i class="bi bi-card-text me-1"></i> Descripción</h6>
                    <p class="mb-0"><?php echo e($product->descripcion ?: '— Sin descripción —'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/products/show.blade.php ENDPATH**/ ?>