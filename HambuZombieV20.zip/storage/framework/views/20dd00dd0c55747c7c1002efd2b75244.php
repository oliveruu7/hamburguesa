
<?php $__env->startSection('title','Recetas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="text-primary">
      <i class="bi bi-list-ul me-2"></i> Lista de Recetas
    </h3>
    <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'recetas.create')): ?>
      <a href="<?php echo e(route('recetas.create')); ?>" class="btn btn-success shadow-sm">
        <i class="bi bi-plus-circle me-1"></i> Nueva Receta
      </a>
    <?php endif; ?>
  </div>

  <?php $__currentLoopData = ['success', 'error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session($msg)): ?>
      <div class="alert alert-<?php echo e($msg == 'success' ? 'success' : 'danger'); ?> alert-dismissible fade show">
        <i class="bi <?php echo e($msg == 'success' ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill'); ?>"></i>
        <?php echo e(session($msg)); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="table-responsive shadow-sm">
    <table class="table table-bordered align-middle text-center">
      <thead class="table-info text-white">
        <tr>
          <th>#</th>
          <th>Hamburguesa</th>
          <th>Insumo</th>
          <th>Cantidad</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($r->idreceta); ?></td>
            <td><?php echo e($r->hamburguesa->nombre); ?></td>
            <td><?php echo e($r->insumo->nombre); ?></td>
            <td><?php echo e($r->cantidad_necesaria); ?></td>
            <td>
              <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'recetas.edit')): ?>
                <a href="<?php echo e(route('recetas.edit', $r)); ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                  <i class="bi bi-pencil-fill"></i>
                </a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="5" class="text-muted">No hay recetas registradas.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/recetas/index.blade.php ENDPATH**/ ?>