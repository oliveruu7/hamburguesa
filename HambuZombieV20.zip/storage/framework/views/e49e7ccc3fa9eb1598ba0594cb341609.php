 
<?php $__env->startSection('title','Nuevo cliente'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  
  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Corrige los siguientes errores:</strong>
      <ul class="mb-0 mt-2">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($err); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  <?php endif; ?>

  <div class="card shadow border-0">
    <div class="card-header text-white" style="background-color:#008080;">
      <h5 class="mb-0"><i class="bi bi-person-plus-fill me-2"></i> Registrar nuevo cliente</h5>
    </div>

    <div class="card-body">
      <form method="POST" action="<?php echo e(route('clientes.store')); ?>" id="clienteForm" novalidate>
        <?php echo csrf_field(); ?>

        
        <div class="mb-3">
          <label class="form-label fw-semibold">
            <i class="bi bi-person-fill"></i> Nombre <span class="text-danger">*</span>
          </label>
          <input type="text" name="nombre" id="nombre"
                 class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 value="<?php echo e(old('nombre')); ?>"
                 maxlength="25" required pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ ]{3,25}" autocomplete="off">
          <div class="valid-feedback">Correcto</div>
          <div class="invalid-feedback">Por favor, ingrese un nombre válido (mín. 3 letras, solo letras y espacios).</div>
          <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
          <label class="form-label fw-semibold">
            <i class="bi bi-card-text"></i> Cédula de Identidad (CI) <span class="text-danger">*</span>
          </label>
          <input type="text" name="ci" id="ci"
                 class="form-control <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 value="<?php echo e(old('ci')); ?>"
                 maxlength="8" minlength="7"
                 pattern="\d{7,8}" required inputmode="numeric"
                 oninput="this.value=this.value.replace(/\D/g,'')">
          <div class="valid-feedback">Correcto</div>
          <div class="invalid-feedback">Solo números. 7 u 8 dígitos.</div>
         
        </div>

        
        <div class="mb-3">
          <label class="form-label fw-semibold">
            <i class="bi bi-telephone-fill"></i> Teléfono
          </label>
          <input type="text" name="telefono" id="telefono"
                 class="form-control <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                 value="<?php echo e(old('telefono')); ?>"
                 maxlength="8" minlength="7"
                 pattern="\d{7,8}" inputmode="numeric"
                 oninput="this.value=this.value.replace(/\D/g,'')">
          <div class="valid-feedback">Correcto</div>
          <div class="invalid-feedback">Solo números. 7 u 8 dígitos.</div>
          <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger small mt-1"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="d-flex justify-content-end">
          <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-secondary me-2">
            <i class="bi bi-x-circle-fill me-1"></i> Cancelar
          </a>
          <button type="submit" class="btn btn-success px-4 opacity-50" id="btnGuardar" disabled>
            <i class="bi bi-save-fill me-1"></i> Guardar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
const form = document.getElementById('clienteForm');
const btn  = document.getElementById('btnGuardar');
const opcionales = ['telefono'];
const textoLimpio = ['nombre'];

// Validación dinámica y limpieza
form.addEventListener('input', e => {
  const el = e.target;
  const name = el.name;

  // Limpiar espacios dobles y caracteres no permitidos en 'nombre'
  if (textoLimpio.includes(name)) {
    el.value = el.value.replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]+/g, '')
                       .replace(/\s{2,}/g, ' ')
                       .trimStart();
  }

  el.classList.remove('is-valid', 'is-invalid');

  if (el.value.trim() !== '' || !opcionales.includes(name)) {
    el.classList.add(el.checkValidity() ? 'is-valid' : 'is-invalid');
  }

  validarFormulario();
});

function validarFormulario() {
  const esValido = form.checkValidity();
  btn.disabled = !esValido;
  btn.classList.toggle('opacity-50', !esValido);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/clientes/create.blade.php ENDPATH**/ ?>