<?php $__env->startSection('title','Editar Usuario'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

    
    <?php $__currentLoopData = ['success','error','info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($t)): ?>
            <div class="alert alert-<?php echo e($t=='success'?'success':($t=='error'?'danger':'warning')); ?>

                        alert-dismissible fade show" role="alert">
                <i class="bi
                   <?php echo e($t=='success'?'bi-check-circle-fill':
                      ($t=='error'?'bi-exclamation-triangle-fill':'bi-info-circle-fill')); ?>"></i>
                <?php echo e(session($t)); ?>

                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($err); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    
    <div class="card shadow border-0">
        <div class="card-header text-white" style="background:#00bcd4;">
            <h5 class="mb-0"><i class="bi bi-pencil-fill me-2"></i> Editar usuario</h5>
        </div>

        <div class="card-body">
            <form id="editForm" method="POST"
                  action="<?php echo e(route('usuarios.update',$usuario->idusuario)); ?>"
                  novalidate autocomplete="off">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                <div class="row g-3">
                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-person-fill"></i> Nombre <span class="text-danger">*</span>
                        </label>
                        <input name="nombre" class="form-control"
                               value="<?php echo e(old('nombre',$usuario->nombre)); ?>"
                               maxlength="25"
                               pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ ]{1,25}" required>
                        <div class="invalid-feedback">Solo letras y espacios (máx 25).</div>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold"><i class="bi bi-telephone-fill"></i> Teléfono</label>
                        <input name="telefono" class="form-control"
                               value="<?php echo e(old('telefono',$usuario->telefono)); ?>"
                               pattern="\d{7,8}" maxlength="8" inputmode="numeric">
                        <div class="invalid-feedback">Solo números (7-8 dígitos).</div>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-envelope-fill"></i> Email <span class="text-danger">*</span>
                        </label>
                        <input name="email" type="email" class="form-control"
                               value="<?php echo e(old('email',$usuario->email)); ?>"
                               maxlength="30"
                               pattern="^[A-Za-z0-9._%+-]{1,25}@gmail\.com$" required>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php if($message==='Este correo ya está registrado.'): ?>
                                
                            <?php else: ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="invalid-feedback">Debe terminar en @gmail.com (máx 30).</div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-lock-fill"></i> Contraseña
                            <small class="text-muted">(vacío = no cambiar)</small>
                        </label>
                        <input name="password" type="password" class="form-control"
                               minlength="6" placeholder="Nueva contraseña (opcional)">
                        <div class="invalid-feedback">Mínimo 6 caracteres.</div>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold"><i class="bi bi-link-45deg"></i> Enlace Perfil</label>
                        <input name="perfil_link" class="form-control"
                               value="<?php echo e(old('perfil_link',$usuario->perfil_link)); ?>"
                               minlength="10" placeholder="https://…">
                        <div class="invalid-feedback">URL no válida (mín 10).</div>
                    </div>

                    
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">
                            <i class="bi bi-person-gear"></i> Rol <span class="text-danger">*</span>
                        </label>
                        <select name="idrol" class="form-select" required>
                            <option value="" disabled>Seleccione un rol…</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rol->idrol); ?>"
                                    <?php echo e(old('idrol',$usuario->idrol)==$rol->idrol?'selected':''); ?>>
                                    <?php echo e($rol->nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="invalid-feedback">Seleccione un rol válido.</div>
                    </div>
                </div>

                
                <div class="mt-4 d-flex justify-content-between">
                    <a href="<?php echo e(route('usuarios.index')); ?>" class="btn btn-secondary px-4">
                        <i class="bi bi-x-circle"></i> Cancelar
                    </a>
                    <button id="btnGuardar" class="btn btn-primary px-4 opacity-50" disabled>
                        <i class="bi bi-save"></i> Guardar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
/* -------- Validación reactiva -------- */
const form = document.getElementById('editForm');
const btn  = document.getElementById('btnGuardar');
const opc  = ['telefono','perfil_link','password'];

form.addEventListener('input', validar);
form.addEventListener('change', validar);
validar();

function validar(){
    btn.disabled = !form.checkValidity();
    btn.classList.toggle('opacity-50',btn.disabled);

    [...form.elements].forEach(el=>{
        if(!['INPUT','SELECT','TEXTAREA'].includes(el.tagName)) return;
        const opcVacio = opc.includes(el.name)&&el.value.trim()==='';
        el.classList.remove('is-valid','is-invalid');               // limpia
        if(el.value.trim()==='') return;                            // vacío
        if(el.checkValidity() && !opcVacio) el.classList.add('is-valid');
        else if(!opcVacio) el.classList.add('is-invalid');
    });
}

/* -------- Filtros de entrada -------- */
const inputNombre   = document.querySelector('input[name="nombre"]');
const inputTelefono = document.querySelector('input[name="telefono"]');

inputNombre.addEventListener('input', () => {
    inputNombre.value = inputNombre.value
        .replace(/[^A-Za-zÁÉÍÓÚáéíóúÑñ ]+/g,'')
        .replace(/\s{2,}/g,' ');
});
inputTelefono.addEventListener('input', () => {
    inputTelefono.value = inputTelefono.value
        .replace(/\D+/g,'').slice(0,8);
});

/* -------- Desvanecer alertas -------- *//*
setTimeout(()=>document.querySelectorAll('.alert').forEach(a=>{
    a.classList.remove('show');a.classList.add('fade');}),3000);*/
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>