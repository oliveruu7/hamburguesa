
<?php $__env->startSection('title','Registrar receta'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="card shadow border-0">
    <div class="card-header text-white" style="background-color: #008080;">
      <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i> Registrar receta</h5>
    </div>
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('recetas.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row g-3">

           <div class="col-md-6">
  <label class="form-label fw-semibold">
    <i class="bi bi-hamburger"></i> Selecciona una hamburguesa <span class="text-danger">*</span>
  </label>
  <select name="idhamburguesa" class="form-select" required>
    <option value="" disabled selected>-- Selecciona --</option>
    <?php $__currentLoopData = $hamburguesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($h->idhamburguesa); ?>"><?php echo e($h->nombre); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  <div class="invalid-feedback">Debe seleccionar una hamburguesa.</div>
</div>


          <div class="col-md-6">
            <label class="form-label fw-semibold">Insumo *</label>
            <select name="idinsumo" class="form-select <?php $__errorArgs = ['idinsumo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
              <option value="" disabled selected>Seleccione...</option>
              <?php $__currentLoopData = $insumos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($i->idinsumo); ?>" <?php echo e(old('idinsumo') == $i->idinsumo ? 'selected' : ''); ?>>
                  <?php echo e($i->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['idinsumo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="col-md-6">
            <label class="form-label fw-semibold">Cantidad necesaria *</label>
            <input type="number" name="cantidad_necesaria" step="0.01" min="0.01" class="form-control <?php $__errorArgs = ['cantidad_necesaria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('cantidad_necesaria')); ?>" required>
            <?php $__errorArgs = ['cantidad_necesaria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="mt-4 d-flex justify-content-end">
          <a href="<?php echo e(route('recetas.index')); ?>" class="btn btn-secondary me-2">
            <i class="bi bi-x-circle-fill"></i> Cancelar
          </a>
          <button type="submit" class="btn btn-success px-4">
            <i class="bi bi-save-fill"></i> Guardar
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/recetas/create.blade.php ENDPATH**/ ?>