
<?php $__env->startSection('title','Salidas de almacén'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold" style="color:#008080">
      <i class="bi bi-box-arrow-up me-2"></i> Salidas registradas
    </h2>
    <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'salidas.create')): ?>
      <a href="<?php echo e(route('salidas.create')); ?>" class="btn text-white" style="background:#008080">
        <i class="bi bi-plus-circle me-1"></i> Nueva salida
      </a>
    <?php endif; ?>
  </div>

  
  <?php $__currentLoopData = ['success'=>'success','error'=>'danger','info'=>'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(session($k)): ?>
        <div class="alert alert-<?php echo e($c); ?> alert-dismissible fade show">
          <?php echo e(session($k)); ?>

          <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div class="card border-0 shadow-sm">
    <div class="table-responsive">
      <table class="table table-bordered align-middle mb-0">
        <thead style="background:#008080;color:#fff" class="text-center">
          <tr>
            <th>#</th>
            <th>Fecha</th>
            <th>Usuario</th>
            <th>Insumos</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="text-center">
              <td><?php echo e($s->idsalida); ?></td>
              <td><?php echo e(\Carbon\Carbon::parse($s->fecha)->format('d/m/Y')); ?></td>
              <td><?php echo e($s->usuario->nombre); ?></td>
              <td><?php echo e($s->detalles->count()); ?></td>
              <td>
                <a href="<?php echo e(route('salidas.show',$s)); ?>" class="btn btn-sm text-white"
                   style="background:#008080" title="Ver">
                  <i class="bi bi-eye-fill"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-muted text-center py-4">No hay salidas registradas.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  
  <div class="mt-3 d-flex justify-content-end">
    <?php echo e($salidas->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/salidas/index.blade.php ENDPATH**/ ?>