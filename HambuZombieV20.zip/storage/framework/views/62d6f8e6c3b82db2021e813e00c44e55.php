
<?php $__env->startSection('title','Registrar nueva compra'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  
  <h3 class="mb-3" style="color:#008080">
    <i class="bi bi-bag-check-fill me-1"></i> Nueva Compra
  </h3>

  
  <?php $__currentLoopData = ['success'=>'success','error'=>'danger','info'=>'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(session($k)): ?>
      <div class="alert alert-<?php echo e($c); ?> alert-dismissible fade show" role="alert">
        <?php echo e(session($k)); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <form id="formCompra" action="<?php echo e(route('compras.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    
    <div class="mb-3">
      <label class="fw-bold" style="color:#008080">Proveedor</label>
      <select name="idproveedor" class="form-select" required>
        <option value="">-- seleccione --</option>
        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($p->idproveedor); ?>"><?php echo e($p->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    
    <table class="table table-bordered" id="tablaInsumos">
      <thead style="background:#008080;color:#fff" class="text-center">
        <tr>
          <th>Insumo</th>
          <th>Cantidad</th>
          <th>Precio</th>
          <th>Subtotal</th>
          <th>
            <button type="button" class="btn btn-light btn-sm fw-bold"
                    onclick="agregarFila()">+</button>
          </th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>

    
    <div class="text-end mb-4">
      <strong style="color:#008080">Total: <span id="totalMostrar">0.00</span> Bs</strong>
      <input type="hidden" name="total" id="total">
    </div>

    
    <div class="d-flex justify-content-between">
      <a href="<?php echo e(route('compras.index')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Volver
      </a>
      <button class="btn text-white" style="background:#008080">
        <i class="bi bi-save me-1"></i> Guardar
      </button>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
const insumos = <?php echo json_encode($insumos, 15, 512) ?>;
/* === Agregar fila === */
function agregarFila(){
  const idx = document.querySelectorAll('#tablaInsumos tbody tr').length;
  const fila = `
  <tr>
    <td>
      <select name="detalles[${idx}][idinsumo]" class="form-select" required>
        <option value="">--</option>
        ${insumos.map(i=>`<option value="${i.idinsumo}">${i.nombre}</option>`).join('')}
      </select>
    </td>
    <td><input type="number" step="0.01" name="detalles[${idx}][cantidad]" class="form-control" oninput="recalcular()" required></td>
    <td><input type="number" step="0.01" name="detalles[${idx}][precio]"   class="form-control" oninput="recalcular()" required></td>
    <td class="subtotal">0.00</td>
    <td>
      <button type="button" class="btn btn-outline-danger btn-sm"
              onclick="this.closest('tr').remove(); recalcular();">−</button>
    </td>
  </tr>`;
  document.querySelector('#tablaInsumos tbody').insertAdjacentHTML('beforeend', fila);
}

/* === Calcular totales === */
function recalcular(){
  let total = 0;
  document.querySelectorAll('#tablaInsumos tbody tr').forEach(tr=>{
      const c = parseFloat(tr.querySelector('[name*="[cantidad]"]').value)||0;
      const p = parseFloat(tr.querySelector('[name*="[precio]"]').value)||0;
      const s = c*p;
      tr.querySelector('.subtotal').textContent = s.toFixed(2);
      total += s;
  });
  document.getElementById('totalMostrar').textContent = total.toFixed(2);
  document.getElementById('total').value = total.toFixed(2);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/compras/create.blade.php ENDPATH**/ ?>