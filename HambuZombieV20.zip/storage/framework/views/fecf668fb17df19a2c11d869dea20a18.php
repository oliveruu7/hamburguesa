
<?php $__env->startSection('title', 'Compras'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">

  
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0" style="color:#008080">
      <i class="bi bi-cart-check me-2"></i> Lista de Compras
    </h3>

    <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'compras.create')): ?>
      <a href="<?php echo e(route('compras.create')); ?>" class="btn text-white shadow-sm"
         style="background:#008080">
        <i class="bi bi-plus-circle me-1"></i> Nueva compra
      </a>
    <?php endif; ?>
  </div>

  
  <?php $__currentLoopData = ['success'=>'success','error'=>'danger','info'=>'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(session($key)): ?>
        <div class="alert alert-<?php echo e($color); ?> alert-dismissible fade show" role="alert">
          <?php echo e(session($key)); ?>

          <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div class="table-responsive shadow-sm">
    <table class="table table-bordered align-middle text-center">
      <thead style="background:#008080;color:#fff">
        <tr>
          <th>#</th>
          <th class="text-start">Proveedor</th>
          <th>Usuario</th>
          <th>Fecha</th>
          <th>Total (Bs)</th>
          <th>Estado</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($c->idcompra); ?></td>
            <td class="text-start"><?php echo e($c->proveedor->nombre); ?></td>
            <td><?php echo e($c->usuario->nombre); ?></td>
            <td><?php echo e($c->fecha); ?></td>
            <td class="fw-bold"><?php echo e(number_format($c->total,2)); ?></td>
            <td>
              <span class="badge <?php echo e($c->estado=='Registrada' ? 'bg-success' : 'bg-danger'); ?>">
                <?php echo e($c->estado); ?>

              </span>
            </td>
            <td>
              <div class="btn-group">
                <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'compras.edit')): ?>
                  <a href="<?php echo e(route('compras.edit',$c)); ?>" class="btn btn-sm text-white"
                     style="background:#008080" title="Editar">
                     <i class="bi bi-pencil-fill"></i>
                  </a>
                <?php endif; ?>

                <?php if (\Illuminate\Support\Facades\Blade::check('permiso', 'compras.delete')): ?>
                  <form action="<?php echo e(route('compras.destroy',$c)); ?>" method="POST"
                        onsubmit="return confirm('¿Anular compra?')" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-outline-danger" title="Anular">
                      <i class="bi bi-trash-fill"></i>
                    </button>
                  </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="7" class="text-muted">No hay compras registradas.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  
  <div class="d-flex justify-content-center mt-3">
    <?php echo e($compras->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP RYZEN 5\hamburgueseria\resources\views/compras/index.blade.php ENDPATH**/ ?>